# Miguelio Aquarius layout for ISO-ESP

## Flashing

qmk flash -kb miguelio/aquarius
