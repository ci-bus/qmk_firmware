# MIGUELIO ROCK

A ANSI + ISO 65% keyboard.

* Keyboard Maintainer: QMK Community
* Hardware Supported: Miguelio Aquarius PCB
* Hardware Availability: [Miguelio.com](https://www.miguelio.com)
* Support contact: [Email](mailto:teclados@miguelio.com)

# Prerequisites

1) qmk installed
2) qmk repository downloaded

## Flashing firmware with RGB and VIA

$ qmk flask -kb miguelio/rock -km rgb
